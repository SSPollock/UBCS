﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BankRPSQL.Models;
using BankRPSQL.ServicesBusiness;
using BankRPSQL.Utils;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BankRPSQL.Pages
{
    public class ShowBalancesModel : PageModel
    {
        IBusinessBanking _ibusbank = null; 
        public ShowBalancesModel(IBusinessBanking ibusbank) 
        { 
            _ibusbank = ibusbank; 
        }

        public decimal CheckingBalance { get; set; }
        public decimal SavingsBalance { get; set; }

        public IActionResult OnGet()
        {
            if (SessionFacade.USERINFO == null)  // not logged in                 
                return RedirectToPage("/Account/Login", new { area = "Identity" });             
            else             
            {                 
                UserInfo uinfo = SessionFacade.USERINFO;                 
                CheckingBalance = _ibusbank.GetCheckingBalance(uinfo.CheckingAccountNumber);                 
                SavingsBalance = _ibusbank.GetSavingsBalance(uinfo.SavingsAccountNumber);             
            }             
            return Page();         
        }
    }
}