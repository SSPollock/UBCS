﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BankRPSQL.Utils
{
    public class ConnectionStringHelper
    {
        public static string CONNSTR = "";
    }
}
